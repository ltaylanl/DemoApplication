package com.example.auth.service;

import com.example.auth.repository.AuthRepository;
import com.example.auth.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService 
{
    @Autowired
    private AuthRepository authRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private LogService logService;

    public void register(User user) 
    {
        try
        {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            authRepository.save(user);
            logService.logAction(user.getUsername(), "REGISTER", "SUCCESS");
        }
        catch(Exception e)
        {
            logService.logAction(user.getUsername(), "REGISTER", "FAILURE");
            throw e;
        }
    }

    public boolean login(String username, String password) 
    {
        User user = authRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) 
        {
            // Kullanıcı bilgilerini DemoApplication'a gönder
            logService.sendUserInfoToDemoApplication(
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhoneNumber()
            );
            return true;
        }
        return false;
    }
}

