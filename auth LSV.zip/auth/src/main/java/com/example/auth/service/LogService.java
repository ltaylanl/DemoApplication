package com.example.auth.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class LogService 
{

    private final RestTemplate restTemplate;

    public LogService(RestTemplate restTemplate) 
    {
        this.restTemplate = restTemplate;
    }

    public void logAction(String username, String action, String status) 
    {
        String logServiceUrl = "http://localhost:8081/logs";

        Map<String, Object> logData = new HashMap<>();
        logData.put("username", username);
        logData.put("timestamp", LocalDateTime.now().toString());
        logData.put("action", action);
        logData.put("status", status);

        // Log Projesine POST isteği gönder
        restTemplate.postForObject(logServiceUrl, logData, Void.class);
    }

    public void sendUserInfoToDemoApplication(String firstName, String lastName, String email, String phoneNumber) 
    {
        String demoApplicationUrl = "http://localhost:8080/user-info";

        Map<String, String> userInfo = new HashMap<>();
        userInfo.put("firstName", firstName);
        userInfo.put("lastName", lastName);
        userInfo.put("email", email);
        userInfo.put("phoneNumber", phoneNumber);

        restTemplate.postForObject(demoApplicationUrl, userInfo, Void.class);
    }
}
