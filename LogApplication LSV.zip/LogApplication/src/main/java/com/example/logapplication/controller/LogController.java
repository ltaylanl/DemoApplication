package com.example.logapplication.controller;

import com.example.logapplication.model.LogEntry;
import com.example.logapplication.repository.LogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/logs")
public class LogController 
{

    @Autowired
    private LogRepository logRepository;

    @PostMapping
    public void saveLog(@RequestBody LogEntry logEntry) 
    {
        logRepository.save(logEntry);
    }
}
