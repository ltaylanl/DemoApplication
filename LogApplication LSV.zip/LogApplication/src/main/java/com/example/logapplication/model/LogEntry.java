package com.example.logapplication.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "log_entry")
public class LogEntry 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username")
    private String username;
    @Column(name = "timestamp")
    private String timestamp;
    @Column(name = "action")
    private String action; // "REGISTER" / "LOGIN"
    @Column(name = "status")
    private String status; // "SUCCESS" / "FAILURE"

    // Getter ve Setter'lar
    public Long getId() 
    {
        return id;
    }
    public void setId(Long id) 
    {
        this.id = id;
    }

    public String getusername() 
    {
        return username;
    }
    public void setusername(String username) 
    {
        this.username = username;
    }

    public String getTimestamp() 
    {
        return timestamp;
    }
    public void setTimestamp(String timestamp) 
    {
        this.timestamp = timestamp;
    }

    public String getAction() 
    {
        return action;
    }
    public void setAction(String action) 
    {
        this.action = action;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    // toString metodu
    @Override
    public String toString() 
    {
        return "LogEntry{" +
                "id=" + id +
                ", username=" + username + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", action='" + action + '\'' +
                ", status='" + status + '\'' +
                '}';
    }

}
