package com.example.log;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = LogApplication.class)
public class LogApplicationTests {

    @Test
    void contextLoads() {
        // Basit bir context yükleme testi
    }
}

