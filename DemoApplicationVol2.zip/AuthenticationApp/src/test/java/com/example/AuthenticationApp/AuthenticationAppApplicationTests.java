package com.example.AuthenticationApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
