package com.example.demo.repository;

import com.example.demo.model.Envanter;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EnvanterRepository extends JpaRepository<Envanter, Long> 
{
    // Kategori'ye göre envanter listeleme
    List<Envanter> findByKategori_Id(Long kategoriId);

    //Tur'a göre envanter listeleme
    List<Envanter> findByTur_Id(Long turId);
}