package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Kategori;
import org.springframework.stereotype.Repository;

@Repository
public interface KategoriRepository extends JpaRepository<Kategori, Long> 
{
    static Kategori findByKategoriId(Long kategori_id) 
    {
        throw new UnsupportedOperationException("Unimplemented method 'findByKategoriId'");
    }
}