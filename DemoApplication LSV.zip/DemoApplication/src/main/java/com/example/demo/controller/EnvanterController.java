package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Envanter;
import com.example.demo.model.Kategori;
import com.example.demo.repository.EnvanterRepository;
import com.example.demo.repository.KategoriRepository;
import com.example.demo.service.EnvanterService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/envanter")
public class EnvanterController 
{

    @Autowired
    private EnvanterRepository envanterRepository;

    @Autowired
    private EnvanterService envanterService;

    @GetMapping
    public List<Envanter> getEnvanterler() 
    {
        return envanterService.getAllEnvanter();
    }

    @PostMapping("/kategori/{kategori_id}")
    public String postMethodName(@RequestBody Long kategori_id) 
    {
        return KategoriRepository.findByKategoriId(kategori_id).getKategoriAdi();
    }
    
    @GetMapping("/kategori/{kategori_id}")
    public Kategori getEnvanterByKategori(@PathVariable Long kategori_id) 
    {
        return envanterRepository.findByKategori_Id(kategori_id).get(0).getKategori();
    }

    @GetMapping("/tur/{tur}")
    public List<Envanter> getEnvanterByTur(@PathVariable Long tur) 
    {
        return envanterRepository.findByTur_Id(tur);
    }
}