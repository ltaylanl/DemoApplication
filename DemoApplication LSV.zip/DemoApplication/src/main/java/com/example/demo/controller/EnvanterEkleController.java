package com.example.demo.controller;

import com.example.demo.model.Envanter;
import com.example.demo.response.EnvanterDTO;
import com.example.demo.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
public class EnvanterEkleController 
{

    @Autowired
    private LogService logService;

    @PostMapping("/envanterEkle")
    public ResponseEntity<?> addEnvanter(@RequestBody EnvanterDTO envanterdto) 
    {
        try 
        {
            // Log: Envanter ekleme işlemi başlatıldı
            logService.logCreate(
                "Envanter",                           
                "Envanter ekleme işlemi başlatıldı.",  
                "AdminUser"                           
            );

            // Envanter ekleme işlemi
            Envanter envanter = new Envanter(
                envanterdto.getIsim(),
                envanterdto.getBarkod(),
                envanterdto.getAdet(),
                envanterdto.getKategori_id(),
                envanterdto.getTurId()
            );

            Map<String, Object> response = new HashMap<>();
            response.put("time", new Date());
            response.put("message", "Envanter eklendi");
            response.put("inventory", envanter);

            // Log: Başarılı işlem
            logService.logCreate(
                "Envanter",
                "Envanter başarıyla eklendi: " + envanter.getBarkod(),
                "AdminUser"
            );

            return ResponseEntity.ok().body(response);
        } 
        catch (Exception e) 
        {
            // Log: Hata
            logService.logCreate(
                "Envanter",
                "Envanter ekleme işlemi başarısız: " + e.getMessage(),
                "AdminUser"
            );
            return ResponseEntity.status(500).body("Envanter ekleme işleminde hata oluştu");
        }
    }
}
