package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.EnvanterRepository;
import com.example.demo.model.Envanter;

@Service
public class EnvanterService 
{

    @Autowired
    private EnvanterRepository envanterRepository;

    public List<Envanter> getAllEnvanter() 
    {
        return envanterRepository.findAll();
    }
}
