package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Envanter 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String isim;

    private String barkod;

    @ManyToOne
    @JoinColumn(name = "kategori_id", nullable = false) // Kategori foreign key ilişkisi
    private Kategori kategori;

    @ManyToOne
    @JoinColumn(name = "tur_id", nullable = false) // Tür foreign key ilişkisi
    private Tur tur;

    private int adet;

    public Envanter() 
    {
    }

    public Envanter(String isim, String barkod, Integer adet, Kategori kategori, Tur tur) 
    {

        this.isim = isim;

        this.barkod = barkod;

        this.adet = adet;

        this.kategori = kategori;

        this.tur = tur;

    }

    // Getter ve Setter
    public Long getId() 
    {
        return id;
    }
    public void setId(Long id) 
    {
        this.id = id;
    }

    public String getIsim() 
    {
        return isim;
    }
    public void setIsim(String isim) 
    {
        this.isim = isim;
    }

    public Kategori getKategori() 
    {
        return kategori;
    }
    public void setKategori(Kategori kategori) 
    {
        this.kategori = kategori;
    }

    public Tur getTur() 
    {
        return tur;
    }
    public void setTur(Tur tur) 
    {
        this.tur = tur;
    }

    public int getAdet() 
    {
        return adet;
    }
    public void setAdet(int adet) 
    {
        this.adet = adet;
    }

    public String getBarkod() 
    {
        return barkod;
    }
    public void setBarkod(String barkod) 
    {
        this.barkod = barkod;
    }

    public String string() 
    {
        return "Envanter{" +
                "id=" + id +
                ", isim='" + isim + '\'' +
                ", kategori=" + kategori +
                ", barkod='" + barkod + '\'' +
                ", tur=" + tur +
                ", adet=" + adet +
                '}';
    }
}
