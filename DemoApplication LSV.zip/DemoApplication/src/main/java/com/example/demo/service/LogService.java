package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class LogService 
{

    @Autowired
    private RestTemplate restTemplate;

    private final String logApplicationUrl = "http://localhost:8081/api/logs";  // LogApplication'ın URL'si

    // Genel bir log gönderme metodu
    private void sendLog(String endpoint, Map<String, String> logData) 
    {
        restTemplate.postForEntity(logApplicationUrl + endpoint, logData, Void.class);
    }

    // CREATE log kaydı
    public void logCreate(String entity, String message, String performedBy) 
    {
        Map<String, String> logData = new HashMap<>();
        logData.put("logType", "CREATE");
        logData.put("entity", entity);
        logData.put("message", message);
        logData.put("performedBy", performedBy != null ? performedBy : "system");
        restTemplate.postForEntity(logApplicationUrl + "/create", logData, Void.class);
    }

    // READ log kaydı
    public void logRead(String entity, String message, String performedBy) 
    {
        Map<String, String> logData = new HashMap<>();
        logData.put("logType", "READ");
        logData.put("entity", entity);
        logData.put("message", message);
        logData.put("performedBy", performedBy != null ? performedBy : "system");
        sendLog("/read", logData);
    }

    // UPDATE log kaydı
    public void logUpdate(String entity, String fields, String oldValue, String newValue, String message, String performedBy) 
    {
        Map<String, String> logData = new HashMap<>();
        logData.put("logType", "UPDATE");
        logData.put("entity", entity);
        logData.put("fields", fields);
        logData.put("oldValue", oldValue);
        logData.put("newValue", newValue);
        logData.put("message", message);
        logData.put("performedBy", performedBy != null ? performedBy : "system");
        sendLog("/update", logData);
    }

    // DELETE log kaydı
    public void logDelete(String entity, String message, String performedBy) 
    {
        Map<String, String> logData = new HashMap<>();
        logData.put("logType", "DELETE");
        logData.put("entity", entity);
        logData.put("message", message);
        logData.put("performedBy", performedBy != null ? performedBy : "system");
        sendLog("/delete", logData);
    }
}
