package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Kategori;
import com.example.demo.repository.KategoriRepository;

@RestController
@RequestMapping("/api/kategoriler")
public class KategoriController 
{

    @Autowired
    private KategoriRepository kategoriRepository;

    @GetMapping
    public List<Kategori> getAllKategoriler() 
    {
        return kategoriRepository.findAll();
    }

    @PostMapping
    public Kategori createKategori(@RequestBody Kategori kategori) 
    {
        return kategoriRepository.save(kategori);
    }
}
