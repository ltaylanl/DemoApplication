package com.example.demo.controller;

import jakarta.servlet.http.HttpServletResponse;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.OutputStream;

@RestController
public class BarcodeController 
{

    @GetMapping("/generateBarcode")
    public void generateBarcode(@RequestParam String code, HttpServletResponse response) 
    {
        try 
        {
            response.setContentType("image/png");
            
            // Barkod oluşturma işlemi
            BitMatrix bitMatrix = new MultiFormatWriter().encode(code, BarcodeFormat.CODE_128, 300, 100);
            
            // Görseli output stream'e yazdır
            try (OutputStream outputStream = response.getOutputStream()) 
            {
                MatrixToImageWriter.writeToStream(bitMatrix, "PNG", outputStream);
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
