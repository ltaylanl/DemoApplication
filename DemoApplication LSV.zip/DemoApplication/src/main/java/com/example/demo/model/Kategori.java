package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Kategori 
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long kategori_id;

    private String kategoriAdi;

    // Getter ve Setter
    public Long getId() 
    {
        return kategori_id;
    }

    public void setId(Long id) 
    {
        this.kategori_id = id;
    }

    public String getKategoriAdi() 
    {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) 
    {
        this.kategoriAdi = kategoriAdi;
    }
}
