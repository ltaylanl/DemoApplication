package com.example.demo.response;

import com.example.demo.model.Kategori;
import com.example.demo.model.Tur;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnvanterDTO 
{
    private String isim;
    private String barkod;
    private Integer adet;
    private Kategori kategori_id;
    private Tur turId;
}
