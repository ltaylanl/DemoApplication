package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import com.example.demo.model.UserInfo;

@RestController
@RequestMapping("/user-info")
public class UserInfoController 
{

    @PostMapping
    public String receiveUserInfo(@RequestBody UserInfo userInfo) 
    {
        // Gelen kullanıcı bilgilerini işleme alabilirsiniz
        System.out.println("Received user info: " + userInfo);
        return "User info received successfully!";
    }
}
