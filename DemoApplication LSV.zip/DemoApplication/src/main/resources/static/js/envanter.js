document.addEventListener('DOMContentLoaded', function () 
{
    // Envanter tablosu sıralama
    const isimHeader = document.getElementById('isimHeader');
    const adetHeader = document.getElementById('adetHeader');
    let isimSortOrder = 'asc';
    let adetSortOrder = 'asc';

    isimHeader.addEventListener('click', function () 
    {
        sortTable('isim', isimSortOrder);
        isimSortOrder = isimSortOrder === 'asc' ? 'desc' : 'asc';
    });

    adetHeader.addEventListener('click', function () 
    {
        sortTable('adet', adetSortOrder);
        adetSortOrder = adetSortOrder === 'asc' ? 'desc' : 'asc';
    });

    function sortTable(column, order) 
    {
        const table = document.getElementById('envanter-table-body');
        const rows = Array.from(table.rows);

        rows.sort((a, b) => 
            {
            const cellA = a.querySelector(`[data-column="${column}"]`).textContent.trim();
            const cellB = b.querySelector(`[data-column="${column}"]`).textContent.trim();

            if (column === 'adet') 
            {
                return order === 'asc' ? cellA - cellB : cellB - cellA;
            } 
            else 
            {
                return order === 'asc' ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
            }
        });

        rows.forEach(row => table.appendChild(row)); // Yeniden sıralanan satırları tabloya ekle
    }

    // Envanter verilerini yükle
    fetch('/api/envanter')
        .then(response => response.json())
        .then(data => 
            {
            const tableBody = document.getElementById('envanter-table-body');
            if (!tableBody) 
            {
                console.error('Tablo gövdesi bulunamadı!');
                return;
            }

            data.forEach(item => 
                {
                const row = document.createElement('tr');

                // İsim hücresi
                const isimCell = document.createElement('td');
                isimCell.textContent = item.isim;
                isimCell.setAttribute('data-column', 'isim'); // Sıralama için veri sütunu
                isimCell.style.textAlign = 'center'; // Ortala
                row.appendChild(isimCell);

                // Barkod hücresi
                const barkodCell = document.createElement('td');
                barkodCell.style.display = 'flex';
                barkodCell.style.alignItems = 'center';
                barkodCell.style.justifyContent = 'center';
                barkodCell.style.gap = '8px'; // Görseller arasına boşluk

                const barkodImg = document.createElement('img');
                barkodImg.src = `/generateBarcode?code=${item.kod}`; // Barkod görseli
                barkodImg.alt = 'Barkod';
                barkodImg.classList.add('barkod-image');
                barkodImg.style.maxWidth = '80px'; // Görsel genişliği
                barkodImg.style.height = 'auto';
                barkodCell.appendChild(barkodImg);

                // Barkod kodu (yanında gösterilecek)
                const kodText = document.createElement('span');
                kodText.textContent = item.kod; // Barkod kodu
                kodText.style.fontSize = '12px';
                kodText.style.color = '#555'; 
                barkodCell.appendChild(kodText);
                row.appendChild(barkodCell);

                // Adet hücresi
                const adetCell = document.createElement('td');
                adetCell.textContent = item.adet;
                adetCell.setAttribute('data-column', 'adet'); // Sıralama için veri sütunu
                adetCell.style.textAlign = 'center';
                row.appendChild(adetCell);

                // Kategori Hücresi
                const kategoriCell = document.createElement('td');
                kategoriCell.textContent = item.kategori.kategoriAdi;
                kategoriCell.style.textAlign = 'center';
                row.appendChild(kategoriCell);

                // Tür Hücresi
                const turCell = document.createElement('td');
                turCell.textContent = item.tur.turAdi;
                turCell.style.textAlign = 'center';
                row.appendChild(turCell);

                // Adet Ekle Hücresi
                const adetEkleCell = document.createElement('button');
                adetEkleCell.textContent = 'Adet Düzenle';
                adetEkleCell.style.backgroundColor = '#4CAF50'; // Yeşil renk
                adetEkleCell.style.color = 'white'; // Beyaz renk
                adetEkleCell.style.border = 'none'; // Kenarlık yok
                adetEkleCell.style.borderRadius = '4px'; // Köşeleri yuvarla
                adetEkleCell.style.padding = '12px 12px'; // İç boşluk
                adetEkleCell.style.cursor = 'pointer'; // İmleç el şeklinde
                adetEkleCell.style.margin = '1px'; // Düğme aralığı
                adetEkleCell.style.fontSize = '14px'; // Yazı boyutu
                row.appendChild(adetEkleCell);

                // Adet Ekleme butonuna tıklanınca
                adetEkleCell.addEventListener('click', function () 
                {
                    const yeniAdet = prompt(`Yeni adet değerini girin (mevcut: ${item.adet}):`);
                    if (yeniAdet === null) return; // İptal butonuna basıldıysa

                    const yeniAdetSayisi = parseInt(yeniAdet);
                    if (isNaN(yeniAdetSayisi)) 
                    {
                        alert('Geçersiz sayı!');
                        return;
                    }

                    else if (yeniAdetSayisi < 0) 
                    {
                        alert('Adet sıfırdan küçük olamaz!');
                        return;
                    }
                    else
                    {
                        alert('Adet başarıyla güncellendi!');
                        return;
                    }
                });

                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Envanter verisi alınırken hata oluştu:', error));
});
