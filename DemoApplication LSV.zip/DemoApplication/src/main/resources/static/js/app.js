document.addEventListener('DOMContentLoaded', function () 
{
    const dropdownContent = document.getElementById('dropdown-content');

    fetch('/api/settings')
        .then(response => response.json())
        .then(data => 
            {
            const dropdownItems = data.dropdownItems;
            const subDropdowns = data.subDropdowns;

            // Dropdown öğelerini oluştur ve ekle
            dropdownItems.forEach(item => 
                {
                const dropdownItemDiv = document.createElement('div');
                dropdownItemDiv.classList.add('dropdown-item');
                dropdownItemDiv.textContent = item;

                dropdownItemDiv.addEventListener('click', function () 
                {
                    if (subDropdowns[item]) 
                    {
                        // Eğer alt menü varsa göster
                        showSubDropdown(subDropdowns[item], item);
                    } 
                    else 
                    {
                        // Alt menü yoksa sayfa yönlendirmesi yap
                        handlePageRedirect(item);
                    }
                });
                dropdownContent.appendChild(dropdownItemDiv);
            });

            // Envanter Ayarları alt menüsü için özel içerik alanı oluştur
            const subDropdownContent = document.createElement('div');
            subDropdownContent.classList.add('sub-dropdown-content');
            subDropdownContent.style.display = 'none'; // Başlangıçta gizli
            dropdownContent.appendChild(subDropdownContent);
        })
        .catch(error => console.error('Ayarlar alınırken hata oluştu:', error));
});

// Alt menüyü göstermek için fonksiyon
function showSubDropdown(items, parent) 
{
    const subDropdownContent = document.querySelector('.sub-dropdown-content');

    // Eğer gösterilen bir alt menü zaten varsa kapat
    if (subDropdownContent.dataset.parent === parent) 
        {
        subDropdownContent.style.display = 'none';
        subDropdownContent.dataset.parent = '';
        return;
    }

    subDropdownContent.innerHTML = ''; // Mevcut içeriği temizle
    subDropdownContent.style.display = 'block';
    subDropdownContent.dataset.parent = parent; // Hangi menüye ait olduğunu işaretle

    items.forEach(setting => 
        {
        const subDropdownItem = document.createElement('div');
        subDropdownItem.classList.add('sub-dropdown-item');
        subDropdownItem.textContent = setting;

        subDropdownItem.addEventListener('click', function () 
        {
            handlePageRedirect(setting);
        });
        subDropdownContent.appendChild(subDropdownItem);
    });
}

// Sayfa yönlendirmesi için fonksiyon
function handlePageRedirect(item) 
{
    const routes = 
    {
        "Uygulama Ayarları": "/uygulama.html",
        "Kullanıcı Ayarları": "/kullanıcı.html",
        "Güvenlik Ayarları": "/güvenlik.html",
        "Gelişmiş Ayarlar": "/gelişmiş.html",
        "Envanter Sayısı": "/envanter.html",
        "Envanter Ekle": "/envanter-ekle.html",
        "Envanter Çıkar": "/envanter-çıkar.html",
        "Ana Sayfaya Dön": "/"
    };
    window.location.href = routes[item] || '/';
}
