package com.example.auth.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AuthLogService {

    private final RestTemplate restTemplate = new RestTemplate();

    public void logLoginAttempt(String username) 
    {
        String logUrl = "http://localhost:8081/log";
        String logMessage = "User " + username + " attempted to login.";
        restTemplate.postForObject(logUrl, logMessage, String.class);
    }
}

